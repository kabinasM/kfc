
import { Box, Button, Center, Divider, Image, Input, Spinner, Stack, Text, useToast } from "@chakra-ui/react";
import { useRouter } from "next/router";
import Link from "next/link";
import { useEffect } from "react";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { authLogin } from "../../Components/redux/actions/auth.actions";
import { getCart } from "../../Components/redux/actions/cart.actions";
let obj={
    email:"",
    password:""
}

export default function Login(){
    let [data,setdata]=useState(obj)
    let dispatch=useDispatch()
    let toast=useToast()
    let router=useRouter()
    const { userRegister: { loading, error, message }, data: { isAuthenticated, token, user,isLogin } } = useSelector(state => state.auth);
    useEffect(()=>{
        if (isLogin) {
            toast({
                title: `Welcome to KFC}`,
                description: "Login successfull",
                status: "success",
                duration: 2000,
                isClosable: true,
            });
            let time = setTimeout(() => {
                dispatch(getCart())
                router.push("/");
            }, 3000);
            return () => clearTimeout(time);
        }
        if (error) {
            toast({
                title: message,
                description: 'Please try again',
                status: "error",
                duration: 2000,
                isClosable: true,
            });
        }

    },[isLogin,error])
    function HandleSignIn(){
       dispatch(authLogin({...data,toast}))

    }
    function HandleForm(e){
        setdata({...data,[e.target.name]:e.target.value})
    }
    if(loading){
        return(<Box w="100%" h="100%"><Center w="100%" h="100%" ><Spinner size={"xl"} /></Center></Box>)
      }
 return (
    <Box>
        <Box w={["90%","90%","35%"]}  m={"auto"} display="grid" gap={5}>
            <Box as="b" fontSize={"14px"}>Sign In / Sign up</Box> 
        <Center>
        <Box>
            <Image src="https://login.kfc.co.in/auth/resources/1vkce/login/kfcIndiaLoginUIDev_2022_08_04/images/KFC_logo.svg" />
        </Box>
        </Center>
        <Box>
            <Text as={"b"} fontSize={["sm","sm","xl"]}>LET’S SIGN IN OR CREATE ACCOUNT WITH YOUR PHONE NUMBER!</Text>
        </Box>
        <Box>
        <Stack spacing={3}>
        <Input variant='flushed' placeholder='Email' name="email" value={data.email} onChange={(e)=>HandleForm(e)}/>
        <Input variant='flushed' placeholder='Password' name="password" type="password" value={data.password} onChange={(e)=>HandleForm(e)}/>

        </Stack>
        </Box>
        <Box>
        <Text fontSize={"12px"}>By “logging in to KFC”, you agree to our Privacy Policy and Terms & Conditions.</Text>
        </Box>
        <Divider />
        <Box w="full">
            <Button w="full" variant='outline' onClick={HandleSignIn}>Sign-In</Button>
        </Box>
        <Box> 
        <Text fontSize={"12px"}>Don't have an account ? {<Link href="/home/signup">Sign-up</Link>}</Text>
        </Box>
        </Box>
    </Box>
 )
}