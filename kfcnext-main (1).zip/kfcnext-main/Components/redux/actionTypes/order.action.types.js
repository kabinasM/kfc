export const POSTORDER="postorder";
export const GETMYORDER="myorder";
export const GETPERTICULER="perticular";
export const LODDING="loading";

