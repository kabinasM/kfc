export const GETPRODUCTS_LODING="menu/loading"
export const GETPRODUCTS_SUCCESS="menu/success"
export const GETPRODUCTS_ERROR="menu/error"

