export const LOGIN="admin/login";
export const ERROR="admin/error";
export const LOADING="admin/loading";
export const LOGOUT="admin/logout";
export const GETPRDERS="admin/getorders";